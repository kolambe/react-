import logo from './logo.svg';
import './App.css';

function App() {
  return (

    <> 
    <div class="container">
    <div className="row">
      <div className="col-md-12 text-center">
        <h3 className="animate-charcter"style={{marginTop:"50px"}}>  C-DAC's PG Diploma Courses Eligibility Criteria.<br />
          CATEGORY 1(SECTION A in C-CAT)</h3>
      </div>
    </div>
  </div>
    <div style={{textAlign:"start"}} className="container">
    <h2>PG-DGi-Post Graduate Diploma in Geoinformics(min 50%)</h2>
   
    <h3>Eligibility:</h3>
    <p>
      * Graduate in Engineering(10+2+4 or 10+3+3 years) in IT/Computer
      Science/Electronics/Telecom/Electrical<br />
      Instrumentation,OR
    </p>
    <p>
      * MSc/MS(10+2+3+2 years) in computer science,IT,Electronics with
      Mathematics in 10+2,OR<br />
    </p>
    <p>
      * 4-Years DEgree in Geoinscience / Petroleum /Mining / Civil/ Planning /
      Architecture / Forest / Agriculture, or related fields or
    </p>
    <p>
      * Post graduate Degree in Geographics / Geology / Natural & Applied
      Science / Mathematics or allied areas.
    </p>
    <p>
      * The canddates must have minimum 50% marks in there qualifying
      Examinations.
    </p>
  </div>
  <div className="container">
      <div className="row">
        <div className="col-md-12 text-center">
          <h3 className="animate-charcter"style={{marginTop:"0px"}}>CATEGORY 2 (Section A +B in C-CAT)</h3>
        </div>
      </div>
    </div>
      <div style={{textAlign:"start"}} className="container">
      <h2>PG-DAC-Post Graduate Diploma in Advanced Computing (Min 50%)</h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or MSc /MS(10+2+3+2 years) in Computer
        Science,IT,Electronics OR
      </p>
      <p>* Graduate in any discipline of Engineering ,OR<br /></p>
      <p>* MCA,MCM,OR <br /></p>
      <p>
        * Post Graduate Degree in Physics / Mathematics / Statistics,OR<br />
      </p>
      <p>
        * Post Graduate Degree in Management with graduation in IT/ Computer /
        Computer Applications <br />
      </p>
      <p>
        * The canddates must have minimum 50% marks in there qualifying
        Examinations.
      </p>
      </div>
      <div style={{textAlign:"start"}} className="container">
      <h2>PG-DMC-Post Graduate Diploma in Mobile Computer(min 50%)</h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or
      </p>

      <p>MSc /MS(10+2+3+2 years) in Computer Science,IT,Electronics OR</p>
      <p>
        * Post Graduate Degree in Management with graduation in IT/ Computer /
        Computer Applications <br />
      </p>
      <p>* MCA</p>
      <p>
        * The canddates must have minimum 50% marks in there qualifying
        Examinations.
      </p>
      </div>
      <div style={{textAlign:"start"}}className="container">
      <h2>PG-DBDA-Post Graduate Diploma in Big Data Analytics(min 50%)</h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or
      </p>
      <p>* MSc /MS(10+2+3+2 years) in Computer Science,IT,Electronics OR</p>
      <p>* Graduate in any discipline of Engineering ,OR</p>
      <p>
        * Post graduate Degree in Management with Corresponnding Bachelor Degree
        in Computer Science,IT,Computer Applications OR
      </p>
      <p>
        * Post Graduate Degree in Physics / Mathematics / Statistics,OR<br />
      </p>
      <p>* MCA,MCM</p>
      <p>
        * The canddates must have minimum 50% marks in there qualifying
        Examinations.
      </p>
      </div>
      <div style={{textAlign:"start"}} className="container">
      <h2>
        PG-DITISS-Post Graduate Diploma in IT Infrastructure,Systems & Security
        (min 55%)
      </h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or
      </p>
      <p>
        * MSc/MS(10+2+3+2 years) in computer science,IT,Electronics with
        Mathematics in 10+2,OR<br />
      </p>
      <p>* MCA</p>
      <p>
        * The canddates must have minimum 50% marks in there qualifying
        Examinations.
      </p>
      </div>
      <div style={{textAlign:"start"}} className="container">
      <h2>PG-DIoT-Post Graduate Diploma in Internet of Things (min 55%)</h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or
      </p>
      <p>
        * MSc/MS(10+2+3+2 years) in computer science,IT,Electronics with
        Mathematics in 10+2,OR<br />
      </p>
      </div>
      <div style={{textAlign:"start"}} className="container">
      <h2>PG-DIoT-Post Graduate Diploma in Internet of Things (min 55%)</h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or
      </p>
      <p>
        * MSc/MS(10+2+3+2 years) in computer science,IT,Electronics with
        Mathematics in 10+2,OR<br />
      </p>
      </div>
        <div style={{textAlign:"start"}} className="container">
      <h2>
        PG-DITISS-Post Graduate Diploma in IT Infrastructure,Systems & Security
        (min 55%)
      </h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or
      </p>
      <p>
        * MSc/MS(10+2+3+2 years) in computer science,IT,Electronics with
        Mathematics in 10+2,OR<br />
      </p>
      <p>* Graduate in any Discipline of Engineering</p>
      <p>* Post Graduate Degree in Physics / Mathematics / Statistics,OR</p>
      <p>* MCA,MCM</p>
      <p>
        * The canddates must have minimum 60% marks in there qualifying
        Examinations.
      </p>
      </div>
      <div style={{textAlign:"start"}} className="container">
      <h2>
        PG-DASSD-Post Graduate Diploma in Advanced Secure Software Development
        (min 55%)
      </h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or
      </p>
      <p>
        * MSc/MS(10+2+3+2 years) in computer science,IT,Electronics with
        Mathematics in 10+2,OR<br />
      </p>
      <p>* Graduate in any Discipline of Engineering</p>
      <p>* Post Graduate Degree in Physics / Mathematics / Statistics,OR</p>
      <p>* MCA,MCM</p>
      <p>
        * The canddates must have minimum 60% marks in there qualifying
        Examinations.
      </p>
      </div>
      <div style={{textAlign:"start"}} className="container">
      <h2>
        PG-DHPCSA-Post Graduate Diploma in HPC Systems administration (min 55%)
      </h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or
      </p>
      <p>
        * MSc/MS(10+2+3+2 years) in computer science,IT,Electronics ,OR<br />
      </p>

      <p>* Post Graduate Degree in Physics / Mathematics / Statistics,OR</p>
      <p>* MCA</p>
      <p>
        * The canddates must have minimum 55% marks in there qualifying
        Examinations.
      </p>
       </div>
       <div style={{textAlign:"start"}} className="container">
      <h2>
        PG-DFBD-Post Graduate Diploma in FinTech and BlockChain Development (min
        60%)
      </h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in any discipline of
        Engineering
      </p>
      <p>
        MCA / MCM or Post Graduate degree in Mathematics / statistics / Physics
      </p>
      <p>
        * The canddates must have minimum 60% marks in there qualifying
        Examinations.
      </p>
       </div>
       <div style={{textAlign:"start"}} className="container">
      <h2>
        PG-DCSF-Post Graduate Diploma Cylinder Security and forensics (min 60%)
      </h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or
      </p>
      <p>
        * MSc/MS(10+2+3+2 years) in computer science,IT,Electronics with
        Mathematics in 10+2,OR<br />
      </p>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in any discipline of
        Engineering
      </p>
      <p>* MCA,MCM</p>
      <p>* Post Graduate Degree in Physics / Mathematics / Statistics,OR</p>
      <p>
        * The canddates must have minimum 60% marks in there qualifying
        Examinations.
      </p>
         </div>
         <div class="container">
        <div class="row">
          <div class="col-md-12 text-center">
            <h3 class="animate-charcter"style={{marginTop:"0px"}}>CATEGORY 3 (Section A+B+C in C-CAT)</h3>
          </div>
        </div>
      </div>
      <h2>
        <div style={{textAlign:"start"}} class="container">
        PG-DCSF-Post Graduate Diploma Cylinder Security and forensics (min 60%)
        </div>
      </h2>
      <div style={{textAlign:"start"}} class="container">
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or
      </p>
      <p>
        * MSc/MS(10+2+3+2 years) in computer science,IT,Electronics with
        Mathematics in 10+2,OR<br />
      </p>
      <p>
        * The canddates must have minimum 55% marks in there qualifying
        Examinations.
      </p>
      </div>
      <div style={{textAlign:"start"}} class="container">
      <h2>PG-DVLSI-Post Graduate Diploma in VLSI Design(min 60%)</h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation
      </p>
      </div>
      <div style={{textAlign:"start"}} class="container">
      <h2>
        PG-DRAT-Post Graduate Diploma in Robotics and Allied Technologies(min
        55%)
      </h2>
      <h3>Eligibility:</h3>
      <p>
        * Graduate Engineering (10+2+4 or 10+3+3 years)in IT / Computer Science
        / Electronics / Telecom / Electrical / <br />
        Instrumentation , Or
      </p>
      <p>
        * MSc/MS(10+2+3+2 years) in computer science,IT,Electronics with
        Mathematics in 10+2,OR
      </p>
      <p>* Graduates in Mechatronics or Mathematics</p>
      </div>
      <div style={{textAlign:"start"}} className="container">
      <h2>There is no age restrictions for admissions in C-DAC's PG Diploma courses<br/> 
    Candidates who have appeared for final examminations of their qualifying<br/>
degree for admissions to the above courses.By qualifyingin C-DAC's<br/>
admissions tests , such candisates can apply for provisional admission in upcoming batch, subject to the conditions that:<br/>
<br/>
<br/>

Note: Candidates are required to ensure that they meet the eligibility criteria <br/>
of the courses for which they are applying. In case any candidate is focused to be<br/>
non -eligible during any stage of the admission process or course delivery<br/>
his/her admission will be cancelled with immidiate effect.</h2>
</div>
     
     


      
    </>
  );
}

export default App;
